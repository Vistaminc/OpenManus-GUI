# Examples

We put some examples in the `examples` directory. All the examples use the same prompt as `Manus`.
The Model we use is `claude3.5`.
