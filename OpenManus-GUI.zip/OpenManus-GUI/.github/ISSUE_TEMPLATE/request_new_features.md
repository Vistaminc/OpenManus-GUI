---
name: "🤔 Request new features"
about: Suggest ideas or features you’d like to see implemented in OpenManus.
title: ''
labels: kind/features
assignees: ''
---

**Feature description**
<!-- Provide a clear and concise description of the proposed feature -->

**Your Feature**
<!-- Explain your idea or implementation process. Optionally, include a Pull Request URL. -->
<!-- Ensure accompanying docs/tests/examples are provided for review. -->
